function Footer() {
    return (
        <div className='footer d-none'>
            Footer
        </div>
    )
}

export default Footer
